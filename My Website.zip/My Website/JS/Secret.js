function doMultiplication() {
  var one = prompt('Number 1');
  var two = prompt('Number 2');
  result = one * two;
  alert(result);
}
function doDivision() {
  var one = prompt('Number 1');
  var two = prompt('Number 2');
  result = one / two;
  alert(result);
}
function doAddition() {
  let one = prompt('Number 1');
  let two = prompt('Number 2');
  result = Number(one) + Number(two);
  alert(result);
}
function doSubtraction() {
  var one = prompt('Number 1');
  var two = prompt('Number 2');
  result = one - two;
  alert(result);
}