let counter = 0;
let clickpower = 1;
let costOne = 100;
let costTwo = 100;
let cps = 0;
document.getElementById("shopOne").innerHTML =  "Click Power: " + costOne + " points";
document.getElementById("shopTwo").innerHTML = "Points/second: " + costTwo + " points";
runWorkers();
updateCounter()

function buttonClicked() {
  counter = counter + clickpower;
  updateCounter();
}

function updateCounter() {
  var textresult = "Points: " + counter;
  document.getElementById("points").innerHTML = textresult;
}

function shopOne() {
  if (counter >= costOne) {
    counter = counter - costOne;
    updateCounter();
    clickpower = clickpower + 1;
    costOne = costOne * 1.5;
    costOne = Math.floor(costOne);
    document.getElementById("shopOne").innerHTML =  "Click Power: " + costOne + " points";
  }
}

function shopTwo() {
  if (counter >= costTwo) {
    counter = counter - costTwo;
    updateCounter();
    cps = cps + 5;
    costTwo = costTwo * 1.5;
    costTwo = Math.floor(costTwo);
    document.getElementById("shopTwo").innerHTML = "Points/second: " + costTwo + " points";
  }
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function runWorkers() {
  while (true) {
    await delay(1000);
    counter = counter + cps;
    updateCounter();
  }
}