function buttonTest() {
  var answer = prompt('You need a password!')
  if (answer == 'abc1234') {
    window.location.href = 'Secret Page.html';
  } else {
      alert('Incorrect!')
  }
}

function openGame() {
  window.location.href = 'Game.html';
}